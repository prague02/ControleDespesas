package com.example.controlededespesas

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.controlededespesas.data.Despesa
import com.example.controlededespesas.DespesaViewModel
import com.google.android.material.textfield.TextInputEditText
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class AdicionarEditarActivity : AppCompatActivity() {

    // Companion object para a chave do 'Extra'
    companion object {
        const val EXTRA_DESPESA = "com.exemplo.controlededespesas.EXTRA_DESPESA"
    }

    private lateinit var etDescricao: TextInputEditText
    private lateinit var etValor: TextInputEditText
    private lateinit var spinnerCategoria: Spinner
    private lateinit var btnSelecionarData: Button
    private lateinit var btnSalvar: Button
    private lateinit var btnExcluir: Button

    // ViewModel
    private val despesaViewModel: DespesaViewModel by viewModels()

    // Variável para guardar a despesa atual (se estiver editando)
    private var despesaAtual: Despesa? = null
    // Variável para guardar a data selecionada (em Long)
    private var dataSelecionada: Long = System.currentTimeMillis()

    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_adicionar_editar)

        // Inicializar Views
        etDescricao = findViewById(R.id.et_descricao)
        etValor = findViewById(R.id.et_valor)
        spinnerCategoria = findViewById(R.id.spinner_categoria)
        btnSelecionarData = findViewById(R.id.btn_selecionar_data)
        btnSalvar = findViewById(R.id.btn_salvar)
        btnExcluir = findViewById(R.id.btn_excluir)

        configurarSpinner()
        configurarDatePicker()

        // Verifica se está em modo "Editar" (recebeu uma Despesa)
        if (intent.hasExtra(EXTRA_DESPESA)) {
            title = "Editar Despesa"
            // Deserializa a despesa
            despesaAtual = intent.getSerializableExtra(EXTRA_DESPESA) as Despesa
            preencherCampos(despesaAtual!!)

            // Mostra o botão excluir
            btnExcluir.visibility = View.VISIBLE
        } else {
            title = "Adicionar Despesa"
            // Atualiza o texto do botão de data com a data atual
            btnSelecionarData.text = dateFormat.format(Date(dataSelecionada))
        }

        // Configurar Listeners dos Botões
        btnSalvar.setOnClickListener {
            salvarDespesa()
        }

        btnExcluir.setOnClickListener {
            confirmarExclusao()
        }
    }

    private fun configurarSpinner() {
        // Cria o adapter usando o array de strings
        ArrayAdapter.createFromResource(
            this,
            R.array.categorias_array,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinnerCategoria.adapter = adapter
        }
    }

    private fun configurarDatePicker() {
        val calendario = Calendar.getInstance()
        // Se estiver editando, usa a data da despesa
        despesaAtual?.let { calendario.timeInMillis = it.data }

        val dateSetListener = DatePickerDialog.OnDateSetListener { _, year, month, dayOfMonth ->
            calendario.set(Calendar.YEAR, year)
            calendario.set(Calendar.MONTH, month)
            calendario.set(Calendar.DAY_OF_MONTH, dayOfMonth)

            // Salva o timestamp (Long)
            dataSelecionada = calendario.timeInMillis
            // Atualiza o texto do botão
            btnSelecionarData.text = dateFormat.format(Date(dataSelecionada))
        }

        btnSelecionarData.setOnClickListener {
            DatePickerDialog(
                this,
                dateSetListener,
                calendario.get(Calendar.YEAR),
                calendario.get(Calendar.MONTH),
                calendario.get(Calendar.DAY_OF_MONTH)
            ).show()
        }
    }

    private fun preencherCampos(despesa: Despesa) {
        etDescricao.setText(despesa.descricao)
        etValor.setText(despesa.valor.toString())

        // Seleciona a categoria no spinner
        val categorias = resources.getStringArray(R.array.categorias_array)
        val pos = categorias.indexOf(despesa.categoria)
        if (pos >= 0) {
            spinnerCategoria.setSelection(pos)
        }

        // Define a data
        dataSelecionada = despesa.data
        btnSelecionarData.text = dateFormat.format(Date(dataSelecionada))
    }

    private fun salvarDespesa() {
        val descricao = etDescricao.text.toString()
        val valorStr = etValor.text.toString()

        // Validação
        if (descricao.isBlank()) {
            etDescricao.error = "Descrição é obrigatória"
            return
        }
        if (valorStr.isBlank()) {
            etValor.error = "Valor é obrigatório"
            return
        }

        val valor = valorStr.toDoubleOrNull()
        if (valor == null || valor <= 0) {
            etValor.error = "Valor inválido"
            return
        }

        val categoria = spinnerCategoria.selectedItem.toString()

        // Cria ou Atualiza a Despesa
        val despesaParaSalvar = despesaAtual?.copy( // Modo Edição (copia o ID)
            descricao = descricao,
            valor = valor,
            categoria = categoria,
            data = dataSelecionada
        ) ?: Despesa( // Modo Adição (ID será gerado pelo Room)
            descricao = descricao,
            valor = valor,
            categoria = categoria,
            data = dataSelecionada
        )

        // Salva no ViewModel
        if (despesaAtual != null) {
            despesaViewModel.atualizar(despesaParaSalvar)
            Toast.makeText(this, "Despesa atualizada", Toast.LENGTH_SHORT).show()
        } else {
            despesaViewModel.inserir(despesaParaSalvar)
            Toast.makeText(this, "Despesa salva", Toast.LENGTH_SHORT).show()
        }

        // Fecha a activity e volta para a MainActivity
        finish()
    }

    private fun confirmarExclusao() {
        // Requisito: Diálogo de confirmação
        AlertDialog.Builder(this)
            .setTitle("Excluir Despesa")
            .setMessage("Tem certeza que deseja excluir '${despesaAtual?.descricao}'?")
            .setPositiveButton("Excluir") { _, _ ->
                // Apenas exclui se tiver uma despesa atual
                despesaAtual?.let {
                    despesaViewModel.deletar(it)
                    Toast.makeText(this, "Despesa excluída", Toast.LENGTH_SHORT).show()
                    finish() // Fecha a activity
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}