package com.example.controlededespesas

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.controlededespesas.data.AppDatabase
import com.example.controlededespesas.data.Despesa
import com.example.controlededespesas.data.DespesaRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

// Usamos AndroidViewModel para ter acesso ao 'Application' context
class DespesaViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: DespesaRepository

    // LiveData pública para a lista de despesas
    val todasDespesas: LiveData<List<Despesa>>

    init {
        // Inicializa o DAO e o Repository
        val despesaDao = AppDatabase.Companion.getDatabase(application).despesaDao()
        repository = DespesaRepository(despesaDao)
        // Converte o Flow (do Room) para LiveData (que a UI pode observar)
        todasDespesas = repository.todasDespesas.asLiveData()
    }

    // Funções para Inserir, Atualizar e Deletar
    // Usamos viewModelScope.launch para rodar em uma coroutine (thread secundária)
    fun inserir(despesa: Despesa) = viewModelScope.launch(Dispatchers.IO) {
        repository.inserir(despesa)
    }

    fun atualizar(despesa: Despesa) = viewModelScope.launch(Dispatchers.IO) {
        repository.atualizar(despesa)
    }

    fun deletar(despesa: Despesa) = viewModelScope.launch(Dispatchers.IO) {
        repository.deletar(despesa)
    }

    // Pega uma despesa por ID e a expõe como LiveData
    fun getDespesaPorId(id: Int): LiveData<Despesa> {
        return repository.getDespesaPorId(id).asLiveData()
    }
}