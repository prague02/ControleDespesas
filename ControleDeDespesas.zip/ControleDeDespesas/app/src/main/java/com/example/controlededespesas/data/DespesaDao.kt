package com.example.controlededespesas.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface DespesaDao {

    // Insere uma nova despesa. Se já existir (pelo ID), substitui.
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun inserir(despesa: Despesa)

    // Atualiza uma despesa existente
    @Update
    suspend fun atualizar(despesa: Despesa)

    // Deleta uma despesa
    @Delete
    suspend fun deletar(despesa: Despesa)

    // Pega uma despesa específica pelo ID
    @Query("SELECT * FROM tabela_despesas WHERE id = :id")
    fun getDespesaPorId(id: Int): Flow<Despesa>

    // Pega todas as despesas, ordenadas da mais recente (data maior) para a mais antiga (data menor)
    @Query("SELECT * FROM tabela_despesas ORDER BY data DESC")
    fun getTodasDespesas(): Flow<List<Despesa>>
}