package com.example.controlededespesas.data

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.controlededespesas.R
import com.example.controlededespesas.data.Despesa
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class DespesaListAdapter(
    private val onItemClickListener: (Despesa) -> Unit
) : ListAdapter<Despesa, DespesaListAdapter.DespesaViewHolder>(DespesasComparator()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DespesaViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_despesa, parent, false)
        return DespesaViewHolder(view)
    }

    override fun onBindViewHolder(holder: DespesaViewHolder, position: Int) {
        val despesaAtual = getItem(position)
        holder.bind(despesaAtual)
        // Define o clique no item
        holder.itemView.setOnClickListener {
            onItemClickListener(despesaAtual)
        }
    }

    class DespesaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val descricaoItemView: TextView = itemView.findViewById(R.id.tv_descricao_item)
        private val categoriaItemView: TextView = itemView.findViewById(R.id.tv_categoria_item)
        private val dataItemView: TextView = itemView.findViewById(R.id.tv_data_item)
        private val valorItemView: TextView = itemView.findViewById(R.id.tv_valor_item)

        // Formatadores (para deixar bonito)
        private val currencyFormat = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
        private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))

        fun bind(despesa: Despesa) {
            descricaoItemView.text = despesa.descricao
            categoriaItemView.text = despesa.categoria
            dataItemView.text = dateFormat.format(Date(despesa.data))
            valorItemView.text = currencyFormat.format(despesa.valor)
        }
    }

    // DiffUtil calcula a diferença entre listas para animar o RecyclerView
    class DespesasComparator : DiffUtil.ItemCallback<Despesa>() {
        override fun areItemsTheSame(oldItem: Despesa, newItem: Despesa): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Despesa, newItem: Despesa): Boolean {
            return oldItem == newItem
        }
    }
}