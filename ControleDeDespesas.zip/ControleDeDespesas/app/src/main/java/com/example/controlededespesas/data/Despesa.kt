package com.example.controlededespesas.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "tabela_despesas")
data class Despesa(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0, // Chave primária que se auto-incrementa

    val descricao: String,
    val valor: Double,
    val categoria: String,
    val data: Long // Salvaremos a data como 'Long' (timestamp) para facilitar a ordenação

) : Serializable
