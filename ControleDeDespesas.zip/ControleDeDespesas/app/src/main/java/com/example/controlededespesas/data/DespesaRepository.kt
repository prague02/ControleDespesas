package com.example.controlededespesas.data

import kotlinx.coroutines.flow.Flow

class DespesaRepository(private val despesaDao: DespesaDao) {

    val todasDespesas: Flow<List<Despesa>> = despesaDao.getTodasDespesas()

    fun getDespesaPorId(id: Int): Flow<Despesa> {
        return despesaDao.getDespesaPorId(id)
    }

    suspend fun inserir(despesa: Despesa) {
        despesaDao.inserir(despesa)
    }

    suspend fun atualizar(despesa: Despesa) {
        despesaDao.atualizar(despesa)
    }

    suspend fun deletar(despesa: Despesa) {
        despesaDao.deletar(despesa)
    }
}