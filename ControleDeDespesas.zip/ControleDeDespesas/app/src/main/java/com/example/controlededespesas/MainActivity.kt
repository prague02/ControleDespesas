package com.example.controlededespesas

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.controlededespesas.AdicionarEditarActivity
import com.example.controlededespesas.data.DespesaListAdapter
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    // Inicializa o ViewModel
    private val despesaViewModel: DespesaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.recycler_view_despesas)
        // Define o adapter e o lambda de clique
        val adapter = DespesaListAdapter { despesaClicada ->
            // Ação de clique: Abrir a tela de Edição
            val intent = Intent(this, AdicionarEditarActivity::class.java)
            intent.putExtra(AdicionarEditarActivity.EXTRA_DESPESA, despesaClicada)
            startActivity(intent)
        }

        recyclerView.adapter = adapter

        // Observa o LiveData do ViewModel
        // Quando os dados no banco mudarem, o 'observer' será chamado
        // e a lista será enviada para o adapter (submitList).
        despesaViewModel.todasDespesas.observe(this) { despesas ->
            despesas?.let { adapter.submitList(it) }
        }

        // Configura o FloatingActionButton (FAB)
        val fab = findViewById<FloatingActionButton>(R.id.fab_adicionar)
        fab.setOnClickListener {
            // Ação do FAB: Abrir a tela de Adicionar
            val intent = Intent(this, AdicionarEditarActivity::class.java)
            startActivity(intent)
        }
    }
}